//
// DeclHandler.cpp
//
// $Id: //poco/1.4/XML/src/DeclHandler.cpp#1 $
//
// Library: XML
// Package: SAX
// Module:  SAX
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/SAX/DeclHandler.h"


namespace Poco {
namespace XML {


DeclHandler::~DeclHandler()
{
}


} } // namespace Poco::XML
